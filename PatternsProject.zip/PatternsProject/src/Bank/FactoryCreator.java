/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bank;

/**
 *
 * @author S541997
 */
public class FactoryCreator {
    
private static FactoryCreator objFactory = new FactoryCreator();
    
    private FactoryCreator(){}
    
    public static FactoryCreator getFactoryCreator()
    {
        
        return objFactory;   
    }
    
    public AbstractFactory getFactory(String store)
    {
        if(store.equals("Bank"))
        {
            return new BankFactory();
        }
                else
        {
                return null;
        }
    
    }
    
}
