/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bank;

/**
 *
 * @author S541997
 */
public class BankFactory extends AbstractFactory{

    @Override
    public Bank getBank(String name) {
       if (name.equals("US"))
            return new US();
       
       else if (name.equals("BOA"))
            return new BOA();
       else
           return null;
    }

    
    
}
